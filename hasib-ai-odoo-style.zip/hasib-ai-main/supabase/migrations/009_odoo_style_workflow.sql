-- ============================================================
-- حاسِب AI — migration 009: منطق عمل بطراز أودوو (Draft → Confirmed/Posted)
--
-- يبني فوق 003-008. يضيف:
--  1) ترقيم تسلسلي رسمي للمستندات (INV/2026/00001 لفواتير البيع،
--     BILL/2026/00001 لفواتير الشراء — تُستخدم لفواتير الموردين
--     المُدخلة يدوياً وفواتير المصروفات المُستخرجة بالذكاء الاصطناعي
--     معاً، لأن كلتيهما محاسبياً "فاتورة مورد" بنفس دفتر اليومية).
--  2) حالة Draft/Posted/Cancelled حقيقية على المستندات — لا قيد محاسبي
--     ولا أثر مخزني يُنشأ إلا عند "الترحيل/التأكيد" (Confirm)، تماماً
--     كما في أودوو: مسودة قابلة للتعديل بحرية ← ترحيل نهائي غير قابل
--     للتعديل مباشرة (يحتاج قيد عكسي/إلغاء لا حذفاً).
--  3) قيد فواتير المصروفات المستخرجة بالذكاء الاصطناعي (الجدول invoices
--     الأصلي) في دفتر الأستاذ العام — كانت تُحسب عرضاً فقط في المتصفح؛
--     الآن تُرحَّل فعلياً مثل أي مستند آخر عند التأكيد.
--  4) سجل نشاط عام (Chatter) بسيط قابل لأي موديول.
-- ============================================================

-- ------------------------------------------------------------
-- 1) الترقيم التسلسلي — يعيد الترقيم من 1 كل سنة ميلادية جديدة تلقائياً
-- ------------------------------------------------------------
create table if not exists doc_sequences (
  org_id uuid not null references organizations(id) on delete cascade,
  code text not null,   -- 'customer.invoice' | 'vendor.bill' | ...
  year int not null,    -- 0 = بلا تصفير سنوي
  next_number int not null default 1,
  primary key (org_id, code, year)
);
alter table doc_sequences enable row level security;
drop policy if exists seq_select on doc_sequences;
create policy seq_select on doc_sequences for select using (is_member(org_id));
-- لا insert/update مباشر: فقط عبر next_sequence() (security definer)

create or replace function next_sequence(p_org_id uuid, p_code text, p_prefix text, p_year_scoped boolean default true)
returns text language plpgsql security definer set search_path = public as $$
declare v_num int; v_year int;
begin
  v_year := case when p_year_scoped then extract(year from current_date)::int else 0 end;
  insert into doc_sequences (org_id, code, year, next_number) values (p_org_id, p_code, v_year, 1)
    on conflict (org_id, code, year) do nothing;
  update doc_sequences set next_number = next_number + 1
    where org_id = p_org_id and code = p_code and year = v_year
    returning next_number - 1 into v_num;
  if p_year_scoped then
    return p_prefix || '/' || v_year || '/' || lpad(v_num::text, 5, '0');
  else
    return p_prefix || lpad(v_num::text, 5, '0');
  end if;
end; $$;

-- ------------------------------------------------------------
-- 2) فواتير البيع — إضافة الحالة والترقيم + مسار Draft ← Confirm منفصل
--    (تبقى record_sale() كما هي تماماً لمن يريد الحفظ المباشر بخطوة
--    واحدة — فقط أضفنا لها رقماً تسلسلياً وحالة 'posted')
-- ------------------------------------------------------------
alter table sales_invoices add column if not exists state text not null default 'posted' check (state in ('draft','posted','cancelled'));
alter table sales_invoices add column if not exists doc_number text;
create unique index if not exists sale_doc_number_unique on sales_invoices(org_id, doc_number) where doc_number is not null;

alter table purchase_invoices add column if not exists state text not null default 'posted' check (state in ('draft','posted','cancelled'));
alter table purchase_invoices add column if not exists doc_number text;
create unique index if not exists pur_doc_number_unique on purchase_invoices(org_id, doc_number) where doc_number is not null;

-- record_sale() و record_purchase() (من migration 003) تبقى تعمل حرفياً
-- كما هي؛ نضيف فقط تعيين رقم تسلسلي وحالة 'posted' على نتيجتهما هنا
-- عبر CREATE OR REPLACE بنفس الجسم + سطرين إضافيين، حتى لا نكرر منطق
-- الترحيل المُختبر مسبقاً في مكانين مختلفين بصيغتين قد تنحرفان.
create or replace function record_sale(
  p_org_id uuid, p_customer_name text, p_invoice_number text, p_invoice_date date,
  p_items jsonb, p_vat_rate numeric, p_payment_method text, p_warehouse_id uuid default null
) returns sales_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_wh uuid; v_customer_id uuid; v_item jsonb;
  v_qty numeric; v_price numeric; v_pid uuid;
  v_prod_name text; v_prod_qty numeric; v_prod_cost numeric;
  v_subtotal numeric(14,2) := 0; v_vat numeric(14,2); v_total numeric(14,2); v_cogs numeric(14,2) := 0;
  v_je uuid; v_lines jsonb := '[]'::jsonb; v_debit_code text; v_debit_memo text;
  v_row sales_invoices; v_doc text;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية تسجيل فواتير بيع لهذه الشركة';
  end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'أضف صنفاً واحداً على الأقل'; end if;

  v_wh := coalesce(p_warehouse_id, ensure_default_warehouse(p_org_id));
  select id into v_customer_id from customers where org_id = p_org_id and lower(name) = lower(trim(p_customer_name)) limit 1;
  if v_customer_id is null then
    insert into customers (org_id, name) values (p_org_id, trim(p_customer_name)) returning id into v_customer_id;
  end if;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_pid := (v_item->>'product_id')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    if v_pid is null then raise exception 'اختر صنفاً لكل بند'; end if;
    if v_qty is null or v_qty <= 0 then raise exception 'كمية غير صحيحة'; end if;
    if v_price is null or v_price < 0 then raise exception 'سعر غير صحيح'; end if;

    select name, quantity, avg_cost into v_prod_name, v_prod_qty, v_prod_cost
      from products where id = v_pid and org_id = p_org_id for update;
    if v_prod_name is null then raise exception 'الصنف غير موجود في هذه الشركة'; end if;
    if v_prod_qty < v_qty then
      raise exception 'الكمية المتوفرة من "%" غير كافية (المتوفر: %, المطلوب: %)', v_prod_name, v_prod_qty, v_qty;
    end if;

    v_subtotal := v_subtotal + (v_qty * v_price);
    v_cogs := v_cogs + (v_qty * v_prod_cost);
    update products set quantity = v_prod_qty - v_qty where id = v_pid;
    insert into stock_moves (org_id, product_id, warehouse_id, move_type, quantity, unit_cost, ref_type, note, created_by)
    values (p_org_id, v_pid, v_wh, 'out', v_qty, v_prod_cost, 'sale', 'بيع إلى ' || p_customer_name, auth.uid());
  end loop;

  v_vat := round(v_subtotal * coalesce(p_vat_rate, 0.15), 2);
  v_total := v_subtotal + v_vat;
  v_cogs := round(v_cogs, 2);

  if p_payment_method = 'cash' then v_debit_code := '1010'; v_debit_memo := 'الصندوق';
  elsif p_payment_method = 'bank' then v_debit_code := '1020'; v_debit_memo := 'البنك';
  elsif p_payment_method = 'receivable' then
    v_debit_code := '1200'; v_debit_memo := 'الذمم المدينة — ' || p_customer_name;
    update customers set balance = balance + v_total where id = v_customer_id;
  else raise exception 'طريقة دفع غير معروفة: %', p_payment_method; end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_code',v_debit_code,'debit',v_total,'credit',0,'memo',v_debit_memo),
    jsonb_build_object('account_code','4000','debit',0,'credit',v_subtotal,'memo','إيرادات مبيعات — ' || coalesce(p_invoice_number,'')),
    jsonb_build_object('account_code','2140','debit',0,'credit',v_vat,'memo','ضريبة مخرجات')
  );
  if v_cogs > 0 then
    v_lines := v_lines || jsonb_build_array(
      jsonb_build_object('account_code','5050','debit',v_cogs,'credit',0,'memo','تكلفة البضاعة المباعة'),
      jsonb_build_object('account_code','1300','debit',0,'credit',v_cogs,'memo','تخفيض المخزون')
    );
  end if;

  v_je := post_journal_entry(p_org_id, coalesce(p_invoice_date, current_date), 'sale', null, 'فاتورة بيع — ' || p_customer_name, v_lines);
  v_doc := next_sequence(p_org_id, 'customer.invoice', 'INV', true);

  insert into sales_invoices (org_id, customer_id, customer_name, invoice_number, invoice_date, items,
    subtotal, vat_amount, vat_rate, total_amount, cogs_amount, payment_method, journal_entry_id, created_by,
    state, doc_number)
  values (p_org_id, v_customer_id, trim(p_customer_name), p_invoice_number, coalesce(p_invoice_date, current_date), p_items,
    v_subtotal, v_vat, coalesce(p_vat_rate,0.15), v_total, v_cogs, p_payment_method, v_je, auth.uid(),
    'posted', v_doc)
  returning * into v_row;

  update journal_entries set source_id = v_row.id where id = v_je;
  return v_row;
end; $$;

-- ------------------------------------------------------------
-- مسار أودوو ذو الخطوتين: مسودة قابلة للتعديل ← تأكيد يرحّل فعلياً
-- ------------------------------------------------------------
create or replace function create_sale_invoice_draft(
  p_org_id uuid, p_customer_name text, p_invoice_number text, p_invoice_date date,
  p_items jsonb, p_vat_rate numeric, p_payment_method text
) returns sales_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_customer_id uuid; v_item jsonb; v_qty numeric; v_price numeric;
  v_subtotal numeric(14,2) := 0; v_vat numeric(14,2); v_total numeric(14,2);
  v_row sales_invoices;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية إنشاء فواتير لهذه الشركة';
  end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'أضف صنفاً واحداً على الأقل'; end if;

  select id into v_customer_id from customers where org_id = p_org_id and lower(name) = lower(trim(p_customer_name)) limit 1;
  if v_customer_id is null then
    insert into customers (org_id, name) values (p_org_id, trim(p_customer_name)) returning id into v_customer_id;
  end if;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::numeric; v_price := (v_item->>'unit_price')::numeric;
    v_subtotal := v_subtotal + coalesce(v_qty,0) * coalesce(v_price,0);
  end loop;
  v_vat := round(v_subtotal * coalesce(p_vat_rate, 0.15), 2);
  v_total := v_subtotal + v_vat;

  insert into sales_invoices (org_id, customer_id, customer_name, invoice_number, invoice_date, items,
    subtotal, vat_amount, vat_rate, total_amount, cogs_amount, payment_method, created_by, state, doc_number)
  values (p_org_id, v_customer_id, trim(p_customer_name), p_invoice_number, coalesce(p_invoice_date, current_date), p_items,
    v_subtotal, v_vat, coalesce(p_vat_rate,0.15), v_total, 0, p_payment_method, auth.uid(), 'draft', null)
  returning * into v_row;
  return v_row;
end; $$;

create or replace function confirm_sale_invoice(p_org_id uuid, p_id uuid)
returns sales_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_inv sales_invoices; v_item jsonb; v_pid uuid; v_qty numeric;
  v_prod_name text; v_prod_qty numeric; v_prod_cost numeric; v_cogs numeric(14,2) := 0;
  v_wh uuid; v_debit_code text; v_debit_memo text; v_lines jsonb; v_je uuid; v_doc text;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية ترحيل فواتير لهذه الشركة';
  end if;
  select * into v_inv from sales_invoices where id = p_id and org_id = p_org_id for update;
  if v_inv.id is null then raise exception 'الفاتورة غير موجودة'; end if;
  if v_inv.state <> 'draft' then raise exception 'الفاتورة ليست مسودة (الحالة الحالية: %)', v_inv.state; end if;

  v_wh := ensure_default_warehouse(p_org_id);
  for v_item in select * from jsonb_array_elements(v_inv.items) loop
    v_pid := (v_item->>'product_id')::uuid; v_qty := (v_item->>'quantity')::numeric;
    select name, quantity, avg_cost into v_prod_name, v_prod_qty, v_prod_cost from products where id = v_pid and org_id = p_org_id for update;
    if v_prod_name is null then raise exception 'صنف محذوف من قائمة الأصناف'; end if;
    if v_prod_qty < v_qty then raise exception 'الكمية المتوفرة من "%" غير كافية (المتوفر: %, المطلوب: %)', v_prod_name, v_prod_qty, v_qty; end if;
    v_cogs := v_cogs + (v_qty * v_prod_cost);
    update products set quantity = v_prod_qty - v_qty where id = v_pid;
    insert into stock_moves (org_id, product_id, warehouse_id, move_type, quantity, unit_cost, ref_type, ref_id, note, created_by)
    values (p_org_id, v_pid, v_wh, 'out', v_qty, v_prod_cost, 'sale', v_inv.id, 'بيع إلى ' || v_inv.customer_name, auth.uid());
  end loop;
  v_cogs := round(v_cogs, 2);

  if v_inv.payment_method = 'cash' then v_debit_code := '1010'; v_debit_memo := 'الصندوق';
  elsif v_inv.payment_method = 'bank' then v_debit_code := '1020'; v_debit_memo := 'البنك';
  else
    v_debit_code := '1200'; v_debit_memo := 'الذمم المدينة — ' || v_inv.customer_name;
    update customers set balance = balance + v_inv.total_amount where id = v_inv.customer_id;
  end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_code',v_debit_code,'debit',v_inv.total_amount,'credit',0,'memo',v_debit_memo),
    jsonb_build_object('account_code','4000','debit',0,'credit',v_inv.subtotal,'memo','إيرادات مبيعات'),
    jsonb_build_object('account_code','2140','debit',0,'credit',v_inv.vat_amount,'memo','ضريبة مخرجات')
  );
  if v_cogs > 0 then
    v_lines := v_lines || jsonb_build_array(
      jsonb_build_object('account_code','5050','debit',v_cogs,'credit',0,'memo','تكلفة البضاعة المباعة'),
      jsonb_build_object('account_code','1300','debit',0,'credit',v_cogs,'memo','تخفيض المخزون')
    );
  end if;

  v_je := post_journal_entry(p_org_id, current_date, 'sale', v_inv.id, 'فاتورة بيع مُرحَّلة — ' || v_inv.customer_name, v_lines);
  v_doc := next_sequence(p_org_id, 'customer.invoice', 'INV', true);

  update sales_invoices set state = 'posted', doc_number = v_doc, journal_entry_id = v_je, cogs_amount = v_cogs
  where id = p_id returning * into v_inv;
  return v_inv;
end; $$;

create or replace function cancel_sale_invoice(p_org_id uuid, p_id uuid) returns sales_invoices
language plpgsql security definer set search_path = public as $$
declare v_inv sales_invoices;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then raise exception 'ليست لديك صلاحية'; end if;
  select * into v_inv from sales_invoices where id = p_id and org_id = p_org_id;
  if v_inv.id is null then raise exception 'الفاتورة غير موجودة'; end if;
  if v_inv.state <> 'draft' then raise exception 'لا يمكن إلغاء فاتورة مُرحَّلة مباشرة — سجّل قيد عكسي بدلاً من ذلك'; end if;
  update sales_invoices set state = 'cancelled' where id = p_id returning * into v_inv;
  return v_inv;
end; $$;

-- ------------------------------------------------------------
-- 3) فواتير الشراء — نفس المعاملة (record_purchase + مسار Draft/Confirm)
-- ------------------------------------------------------------
create or replace function record_purchase(
  p_org_id uuid, p_supplier_name text, p_invoice_number text, p_invoice_date date,
  p_items jsonb, p_vat_rate numeric, p_payment_method text, p_warehouse_id uuid default null
) returns purchase_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_wh uuid; v_vendor_id uuid; v_item jsonb;
  v_qty numeric; v_cost numeric; v_name text; v_sku text;
  v_subtotal numeric(14,2) := 0; v_vat numeric(14,2); v_total numeric(14,2);
  v_je uuid; v_lines jsonb := '[]'::jsonb; v_credit_code text; v_credit_memo text;
  v_prod_id uuid; v_prod_qty numeric; v_prod_cost numeric; v_row purchase_invoices; v_doc text;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية تسجيل فواتير شراء لهذه الشركة';
  end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'أضف صنفاً واحداً على الأقل'; end if;

  v_wh := coalesce(p_warehouse_id, ensure_default_warehouse(p_org_id));
  select id into v_vendor_id from vendors where org_id = p_org_id and lower(name) = lower(trim(p_supplier_name)) limit 1;
  if v_vendor_id is null then
    insert into vendors (org_id, name) values (p_org_id, trim(p_supplier_name)) returning id into v_vendor_id;
  end if;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::numeric; v_cost := (v_item->>'unit_cost')::numeric;
    v_name := trim(v_item->>'product_name'); v_sku := nullif(trim(coalesce(v_item->>'sku','')), '');
    if v_qty is null or v_qty <= 0 then raise exception 'كمية الصنف "%" غير صحيحة', v_name; end if;
    if v_cost is null or v_cost < 0 then raise exception 'تكلفة الصنف "%" غير صحيحة', v_name; end if;
    v_subtotal := v_subtotal + (v_qty * v_cost);

    select id, quantity, avg_cost into v_prod_id, v_prod_qty, v_prod_cost
      from products where org_id = p_org_id
      and ((v_sku is not null and sku = v_sku) or (v_sku is null and lower(name) = lower(v_name)))
      limit 1 for update;

    if v_prod_id is null then
      insert into products (org_id, warehouse_id, sku, name, quantity, avg_cost, selling_price)
      values (p_org_id, v_wh, v_sku, v_name, v_qty, v_cost, round(v_cost * 1.3, 2))
      returning id into v_prod_id;
    else
      update products set quantity = v_prod_qty + v_qty,
        avg_cost = case when (v_prod_qty + v_qty) > 0 then round(((v_prod_qty * v_prod_cost) + (v_qty * v_cost)) / (v_prod_qty + v_qty), 4) else v_cost end
      where id = v_prod_id;
    end if;

    insert into stock_moves (org_id, product_id, warehouse_id, move_type, quantity, unit_cost, ref_type, note, created_by)
    values (p_org_id, v_prod_id, v_wh, 'in', v_qty, v_cost, 'purchase', 'شراء من ' || p_supplier_name, auth.uid());
  end loop;

  v_vat := round(v_subtotal * coalesce(p_vat_rate, 0.15), 2);
  v_total := v_subtotal + v_vat;

  if p_payment_method = 'cash' then v_credit_code := '1010'; v_credit_memo := 'الصندوق';
  elsif p_payment_method = 'bank' then v_credit_code := '1020'; v_credit_memo := 'البنك';
  elsif p_payment_method = 'payable' then
    v_credit_code := '2100'; v_credit_memo := 'الدائنون — ' || p_supplier_name;
    update vendors set balance = balance + v_total where id = v_vendor_id;
  else raise exception 'طريقة دفع غير معروفة: %', p_payment_method; end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_code','1300','debit',v_subtotal,'credit',0,'memo','مخزون — فاتورة شراء ' || coalesce(p_invoice_number,'')),
    jsonb_build_object('account_code','2130','debit',v_vat,'credit',0,'memo','ضريبة مدخلات'),
    jsonb_build_object('account_code',v_credit_code,'debit',0,'credit',v_total,'memo',v_credit_memo)
  );

  v_je := post_journal_entry(p_org_id, coalesce(p_invoice_date, current_date), 'purchase', null, 'فاتورة شراء — ' || p_supplier_name, v_lines);
  v_doc := next_sequence(p_org_id, 'vendor.bill', 'BILL', true);

  insert into purchase_invoices (org_id, vendor_id, supplier_name, invoice_number, invoice_date, items,
    subtotal, vat_amount, vat_rate, total_amount, payment_method, journal_entry_id, created_by, state, doc_number)
  values (p_org_id, v_vendor_id, trim(p_supplier_name), p_invoice_number, coalesce(p_invoice_date, current_date), p_items,
    v_subtotal, v_vat, coalesce(p_vat_rate,0.15), v_total, p_payment_method, v_je, auth.uid(), 'posted', v_doc)
  returning * into v_row;

  update journal_entries set source_id = v_row.id where id = v_je;
  return v_row;
end; $$;

create or replace function create_purchase_invoice_draft(
  p_org_id uuid, p_supplier_name text, p_invoice_number text, p_invoice_date date,
  p_items jsonb, p_vat_rate numeric, p_payment_method text
) returns purchase_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_vendor_id uuid; v_item jsonb; v_qty numeric; v_cost numeric;
  v_subtotal numeric(14,2) := 0; v_vat numeric(14,2); v_total numeric(14,2); v_row purchase_invoices;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية إنشاء فواتير شراء لهذه الشركة';
  end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'أضف صنفاً واحداً على الأقل'; end if;

  select id into v_vendor_id from vendors where org_id = p_org_id and lower(name) = lower(trim(p_supplier_name)) limit 1;
  if v_vendor_id is null then
    insert into vendors (org_id, name) values (p_org_id, trim(p_supplier_name)) returning id into v_vendor_id;
  end if;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::numeric; v_cost := (v_item->>'unit_cost')::numeric;
    v_subtotal := v_subtotal + coalesce(v_qty,0) * coalesce(v_cost,0);
  end loop;
  v_vat := round(v_subtotal * coalesce(p_vat_rate, 0.15), 2);
  v_total := v_subtotal + v_vat;

  insert into purchase_invoices (org_id, vendor_id, supplier_name, invoice_number, invoice_date, items,
    subtotal, vat_amount, vat_rate, total_amount, payment_method, created_by, state, doc_number)
  values (p_org_id, v_vendor_id, trim(p_supplier_name), p_invoice_number, coalesce(p_invoice_date, current_date), p_items,
    v_subtotal, v_vat, coalesce(p_vat_rate,0.15), v_total, p_payment_method, auth.uid(), 'draft', null)
  returning * into v_row;
  return v_row;
end; $$;

create or replace function confirm_purchase_invoice(p_org_id uuid, p_id uuid) returns purchase_invoices
language plpgsql security definer set search_path = public as $$
declare
  v_inv purchase_invoices; v_item jsonb; v_qty numeric; v_cost numeric; v_name text; v_sku text;
  v_prod_id uuid; v_prod_qty numeric; v_prod_cost numeric; v_wh uuid;
  v_credit_code text; v_credit_memo text; v_lines jsonb; v_je uuid; v_doc text;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then raise exception 'ليست لديك صلاحية ترحيل فواتير لهذه الشركة'; end if;
  select * into v_inv from purchase_invoices where id = p_id and org_id = p_org_id for update;
  if v_inv.id is null then raise exception 'الفاتورة غير موجودة'; end if;
  if v_inv.state <> 'draft' then raise exception 'الفاتورة ليست مسودة (الحالة الحالية: %)', v_inv.state; end if;

  v_wh := ensure_default_warehouse(p_org_id);
  for v_item in select * from jsonb_array_elements(v_inv.items) loop
    v_qty := (v_item->>'quantity')::numeric; v_cost := (v_item->>'unit_cost')::numeric;
    v_name := trim(v_item->>'product_name'); v_sku := nullif(trim(coalesce(v_item->>'sku','')), '');
    select id, quantity, avg_cost into v_prod_id, v_prod_qty, v_prod_cost from products
      where org_id = p_org_id and ((v_sku is not null and sku = v_sku) or (v_sku is null and lower(name) = lower(v_name))) limit 1 for update;
    if v_prod_id is null then
      insert into products (org_id, warehouse_id, sku, name, quantity, avg_cost, selling_price)
      values (p_org_id, v_wh, v_sku, v_name, v_qty, v_cost, round(v_cost * 1.3, 2)) returning id into v_prod_id;
    else
      update products set quantity = v_prod_qty + v_qty,
        avg_cost = case when (v_prod_qty + v_qty) > 0 then round(((v_prod_qty * v_prod_cost) + (v_qty * v_cost)) / (v_prod_qty + v_qty), 4) else v_cost end
      where id = v_prod_id;
    end if;
    insert into stock_moves (org_id, product_id, warehouse_id, move_type, quantity, unit_cost, ref_type, ref_id, note, created_by)
    values (p_org_id, v_prod_id, v_wh, 'in', v_qty, v_cost, 'purchase', v_inv.id, 'شراء من ' || v_inv.supplier_name, auth.uid());
  end loop;

  if v_inv.payment_method = 'cash' then v_credit_code := '1010'; v_credit_memo := 'الصندوق';
  elsif v_inv.payment_method = 'bank' then v_credit_code := '1020'; v_credit_memo := 'البنك';
  else
    v_credit_code := '2100'; v_credit_memo := 'الدائنون — ' || v_inv.supplier_name;
    update vendors set balance = balance + v_inv.total_amount where id = v_inv.vendor_id;
  end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_code','1300','debit',v_inv.subtotal,'credit',0,'memo','مخزون'),
    jsonb_build_object('account_code','2130','debit',v_inv.vat_amount,'credit',0,'memo','ضريبة مدخلات'),
    jsonb_build_object('account_code',v_credit_code,'debit',0,'credit',v_inv.total_amount,'memo',v_credit_memo)
  );
  v_je := post_journal_entry(p_org_id, current_date, 'purchase', v_inv.id, 'فاتورة شراء مُرحَّلة — ' || v_inv.supplier_name, v_lines);
  v_doc := next_sequence(p_org_id, 'vendor.bill', 'BILL', true);

  update purchase_invoices set state = 'posted', doc_number = v_doc, journal_entry_id = v_je where id = p_id returning * into v_inv;
  return v_inv;
end; $$;

create or replace function cancel_purchase_invoice(p_org_id uuid, p_id uuid) returns purchase_invoices
language plpgsql security definer set search_path = public as $$
declare v_inv purchase_invoices;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then raise exception 'ليست لديك صلاحية'; end if;
  select * into v_inv from purchase_invoices where id = p_id and org_id = p_org_id;
  if v_inv.id is null then raise exception 'الفاتورة غير موجودة'; end if;
  if v_inv.state <> 'draft' then raise exception 'لا يمكن إلغاء فاتورة مُرحَّلة مباشرة — سجّل قيد عكسي بدلاً من ذلك'; end if;
  update purchase_invoices set state = 'cancelled' where id = p_id returning * into v_inv;
  return v_inv;
end; $$;

-- ------------------------------------------------------------
-- 4) فواتير المصروفات المستخرجة بالذكاء الاصطناعي — تدخل دفتر الأستاذ
--    العام رسمياً الآن عند "الترحيل" بدل الاكتفاء بعرضها في المتصفح.
--    الواجهة (JS) تحسب الحساب المدين/الدائن النهائي بمنطقها الحالي
--    (المرادفات + المطابقة) وتخزّنه في resolved_debit_code/
--    resolved_credit_code وقت الحفظ — الدالة هنا تقرأ هذين العمودين
--    مباشرة فلا تُكرَّر منطق المطابقة في SQL وتتفادى أي انحراف بين
--    الطبقتين.
-- ------------------------------------------------------------
alter table invoices add column if not exists state text;
update invoices set state = case when approved then 'posted' else 'draft' end where state is null;
alter table invoices alter column state set default 'draft';
do $$ begin
  alter table invoices add constraint invoices_state_check check (state in ('draft','posted','cancelled'));
exception when duplicate_object then null; end $$;
alter table invoices add column if not exists doc_number text;
alter table invoices add column if not exists journal_entry_id uuid references journal_entries(id) on delete set null;
alter table invoices add column if not exists resolved_debit_code text;
alter table invoices add column if not exists resolved_credit_code text;

create or replace function confirm_ai_invoice(p_org_id uuid, p_invoice_id uuid)
returns invoices
language plpgsql security definer set search_path = public as $$
declare v_inv invoices; v_lines jsonb; v_je uuid; v_doc text;
begin
  if not has_role(p_org_id, array['owner','accountant']::app_role[]) then
    raise exception 'ليست لديك صلاحية ترحيل فواتير لهذه الشركة';
  end if;
  select * into v_inv from invoices where id = p_invoice_id and org_id = p_org_id for update;
  if v_inv.id is null then raise exception 'الفاتورة غير موجودة'; end if;
  if v_inv.state = 'posted' then raise exception 'الفاتورة مُرحَّلة مسبقاً'; end if;
  if v_inv.resolved_debit_code is null or v_inv.resolved_credit_code is null then
    raise exception 'لم تُحدَّد حسابات القيد بعد — احفظ/اعتمد الفاتورة من الشاشة أولاً حتى تُحسَب تلقائياً';
  end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_code', v_inv.resolved_debit_code, 'debit', coalesce(v_inv.subtotal,0), 'credit', 0, 'memo', 'مصروف — ' || coalesce(v_inv.vendor_name,'')),
    jsonb_build_object('account_code', '2130', 'debit', coalesce(v_inv.vat_amount,0), 'credit', 0, 'memo', 'ضريبة مدخلات'),
    jsonb_build_object('account_code', v_inv.resolved_credit_code, 'debit', 0, 'credit', coalesce(v_inv.total_amount,0), 'memo', coalesce(v_inv.vendor_name,''))
  );
  v_je := post_journal_entry(p_org_id, coalesce(v_inv.invoice_date, current_date), 'invoice', v_inv.id, 'فاتورة مصروف (AI) — ' || coalesce(v_inv.vendor_name,''), v_lines);
  v_doc := next_sequence(p_org_id, 'vendor.bill', 'BILL', true);

  update invoices set state = 'posted', approved = true, doc_number = v_doc, journal_entry_id = v_je
  where id = p_invoice_id returning * into v_inv;
  return v_inv;
end; $$;

-- ------------------------------------------------------------
-- 5) سجل نشاط عام (Chatter مبسّط) — قابل للاستخدام مع أي موديول
-- ------------------------------------------------------------
create table if not exists activity_log (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organizations(id) on delete cascade,
  model_name text not null,   -- 'sales_invoices' | 'purchase_invoices' | 'invoices' | 'fixed_assets' | 'crm_opportunities' ...
  record_id uuid not null,
  body text not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists activity_log_idx on activity_log(org_id, model_name, record_id, created_at desc);

alter table activity_log enable row level security;
drop policy if exists activity_log_select on activity_log;
create policy activity_log_select on activity_log for select using (is_member(org_id));
drop policy if exists activity_log_insert on activity_log;
create policy activity_log_insert on activity_log for insert with check (is_member(org_id));
